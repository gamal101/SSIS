USE Wistful
GO

CREATE TABLE UKBuiltUpAreas(
	Rank int NULL,
	AreaName varchar(255) NULL,
	Population bigint NULL
)

GO

SELECT * FROM UKBuiltUpAreas